//const home_client=require('routes/anime_client/root/home_route')  ;

var myRoutes = require('./routes/index.js');

const express = require("express");
const app = express();
const PORT = process.env.PORT || 3000;



app.use([myRoutes]).listen(PORT, () => {
  console.log(`Server listening on ${PORT}`);
});