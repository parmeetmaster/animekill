/*

const Failure=require('../../models/core_models/failure_model')
var admin = require("firebase-admin");
var serviceAccount = require("../../assets/animekill-4439c-firebase-adminsdk-ytodb-1d15f90c57.json");





const BUCKET_NAME= 'gs://animekill-4439c.appspot.com';


const fireBaseConfig={
    credential: admin.credential.cert(serviceAccount),
    storageBucket: BUCKET_NAME,
    bucketName: BUCKET_NAME,
};

//ADMIN INIT
admin.initializeApp(fireBaseConfig);

var bucket = admin.storage().bucket();


const firebaseBucketAddImage = async (image,name) => {
    bucket.deleteFiles()
}



*/



