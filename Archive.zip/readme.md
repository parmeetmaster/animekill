UPDATE `AnimekillDetails` SET `last_update` = CURRENT_TIMESTAMP WHERE `AnimekillDetails`.`sno` = 1

express formidable is used to get form data